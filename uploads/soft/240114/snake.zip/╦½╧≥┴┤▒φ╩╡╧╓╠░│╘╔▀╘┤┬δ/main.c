#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <Windows.h>
#include "snake.h"

int main(void)
{
	bool game_over = false;
	char direct = 'a', input;
	Food food = CreateFood();
	pNode head = InitSnake();
	HideCursor();
	do {
		head = EatFood(head, &food);
		input = CheckKey(direct);
		if (27 == input) {
			game_over = true;
			break;
		}
		else {
			direct = input;
		}
		game_over = Move(head, direct);
		system("cls");
		Show(head, food);
		Sleep(100);
	} while (game_over == false);
	if (game_over) {
		printf("��Ϸ������\n");
		ExitGame(&head);
		getch();
	}
	return 0;
}